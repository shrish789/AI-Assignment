import time
import math
from initial import *
from solution import *


def show_output(gene,startState,goalState):
    print("Start State : ")
    show(startState)
    print("Goal State : ")
    show(goalState)
    print("Optimal gene found is: ")
    print(gene)
    print("Number of states to optimal path = " + str(len(gene)))
    print("Optimal path is :")
    show(startState)
    temp = startState

    prevState = temp

    for move in gene:
        idx = np.where(temp == 0)

        y = int(idx[0])
        x = int(idx[1])

        # blank can go up
        if (move == 'up' and y != 0):
            temp[y][x] = temp[y-1][x]
            temp[y-1][x] = 0

        # blank can go down
        if (move == 'down' and y != 2):
            temp[y][x] = temp[y+1][x]
            temp[y+1][x] = 0

        # blank can go to the left
        if (move == 'left' and x != 0):
            temp[y][x] = temp[y][x-1]
            temp[y][x-1] = 0

        # blank can go to the right
        if (move == 'right' and x != 2):
            temp[y][x] = temp[y][x+1]
            temp[y][x+1] = 0

        # if np.array_equal(prevState,temp):
        #     break
        prevState = temp
        show(temp)


if __name__ == '__main__':

    #To read the file
    startState = ""
    goalState = ""
    with open("StartState") as f:
        for line in f:
            line = line.strip()
            line = line.replace(" ", "")
            startState += line
    startState = replaceTB(startState)
    startState = convertStringToMatrix(startState)
    startState = np.array(startState)

    with open("GoalState") as f:
        for line in f:
            line = line.strip()
            line = line.replace(" ", "")
            goalState += line

    goalState = replaceTB(goalState)
    goalState = convertStringToMatrix(goalState)
    goalState = np.array(goalState)

    # show menu
    print("Enter the Heuristic: ")
    print("1. h1(n) = number of tiles displaced from their destined position")
    print("2. h2(n) = sum of Manhattan distance of each tiles from the goal position.")


    # retrieve choice.
    choice = int(input("Enter your choice: "))
    if choice > 2 or choice <1:
        print("Invalid Choice.......\n")
    else:
        start = time.process_time()
        optimal_gene = genetic_algorithm(startState,goalState,choice)
        show_output(optimal_gene,startState,goalState)
        print("Time taken by the program in seconds: ")
        print(time.process_time() - start)


