import time
import random
import math

successOrFailure = False
temp1 = 0
numberOfStates = 50000
finalPath = ""

def replaceTB(txt):
    txt = txt.replace("T", " ")
    txt = txt.replace("B", " 0")
    return txt

# manhattan_distance
def findManDist(bArray):
    distance = 0
    for i in range(len(bArray)):
        distance += abs(i/3 - bArray[i]/3) + abs(i%3 - bArray[i]%3)
    return distance

# accept the random choice with certain probability
def nextStepAnnealing(bArray):
    TEMPERATURE = len(bArray)
    rateOfAnnealing = 0.95

    global finalPath

    for i in range(len(bArray)):
        if bArray[i] == 0:
            break
    distance = findManDist(bArray)
    TEMPERATURE = max(TEMPERATURE * rateOfAnnealing, 0.02)
    # print(TEMPERATURE)
    global temp1
    temp1 = TEMPERATURE
    while True:
        randCase = random.randint(0,4)
        if randCase == 0:
            if i >= 3:
                upBoard = list(bArray)
                upBoard[i] = bArray[i-3]
                upBoard[i-3] = 0
                # global finalPath
                finalPath += "U "
                if findManDist(upBoard) < distance:
                    return upBoard
                else:
                    deltaE = findManDist(upBoard) - distance
                    acceptProbability = min(math.exp(deltaE / TEMPERATURE), 1)
                    if random.random() <= acceptProbability:
                        return upBoard
        elif randCase == 1:
            if i < 6:
                downBoard = list(bArray)
                downBoard[i] = bArray[i+3]
                downBoard[i+3] = 0
                # global finalPath
                finalPath += "D "
                if findManDist(downBoard) < distance:
                    return downBoard
                else:
                    deltaE = findManDist(downBoard) - distance
                    acceptProbability = min(math.exp(deltaE / TEMPERATURE), 1)
                    if random.random() <= acceptProbability:
                        return downBoard
        elif randCase == 2:
            if i%3 != 0:
                leftBoard = list(bArray)
                leftBoard[i] = bArray[i-1]
                leftBoard[i-1] = 0
                # global finalPath
                finalPath += "L "
                if findManDist(leftBoard) < distance:
                    return leftBoard
                else:
                    deltaE = findManDist(leftBoard) - distance
                    acceptProbability = min(math.exp(deltaE / TEMPERATURE), 1)
                    if random.random() <= acceptProbability:
                        return leftBoard
        else:
            if (i+1)%3 != 0:
                rightBoard = list(bArray)
                rightBoard[i] = bArray[i+1]
                rightBoard[i+1] = 0
                # global finalPath
                finalPath += "R "
                if findManDist(rightBoard) < distance:
                    return rightBoard
                else:
                    deltaE = findManDist(rightBoard) - distance
                    acceptProbability = min(math.exp(deltaE / TEMPERATURE), 1)
                    if random.random() <= acceptProbability:
                        return rightBoard
    return bArray

def doAnnealing(bArray):
    # the success rate will increase by increasing the maxRound
    maxRound = 500000
    count = 0
    while True:
        collisionNum = findManDist(bArray)
        if collisionNum == 0:
            # print(count)
            global numberOfStates
            numberOfStates = count
            return bArray
        bArray = nextStepAnnealing(bArray)
        count += 1
        if(count >= maxRound):
            global successOrFailure
            successOrFailure = True
            return bArray

def main():
    title = "Simulated Annealing Result: "
    startTime = time.process_time()
    startState = ""
    successCase = 0
    totalCase = 0

    print("Enter the Heuristic: ")
    print("1. h1(n) = number of tiles displaced from their destined position")
    print("2. h2(n) = sum of Manhattan distance of each tiles from the goal position.")

    choice = int(input("Enter your choice: "))
    if choice > 2 or choice <1:
        print("Invalid Choice.......\n")
        return


    with open("StartState") as f:
        for line in f:
            line = line.strip()
            line = line.replace(" ", "")
            line = line.replace("\n", " ")
            startState += line
    startState = replaceTB(startState)

    f1 = open('eightPuzzleTest.txt', 'w')
    f1.write(startState)
    f1.close()

    startState = startState.replace(" ", "")
    startState1 = ""
    for x in range(len(startState)):
        if (x+1)%3==0:
            startState1 += startState[x] + "\n"
        else:
            startState1 += startState[x] + " "

    result = title + "\n\n"
    with open("eightPuzzleTest.txt", "r") as ins:
        for line in ins:
            global successOrFailure
            successOrFailure = False
            totalCase += 1
            bArray = []
            for col in line.split():
                bArray.append(int(col))
            bArray = doAnnealing(bArray)
            if successOrFailure:
                result += "Failed!\n"
            else:
                successCase += 1
                result += "Success\n"
            # result += "\n"

    result += "\nStart State:\n"
    result += startState1 + "\n"
    result += "\nGoal State:\n"
    result += "0 1 2\n3 4 5\n6 7 8\n\n"
    global temp1
    result += "Temperature: " + str(temp1) + "\n"
    global numberOfStates
    global finalPath
    result += "Number of States visited: " + str(numberOfStates) + "\n"
    endTime = time.process_time()
    result += "\nTotal time: " + str(endTime - startTime) + '\n'

    print(result)

    f = open(title + '.txt', 'w')
    f.write(result)
    f.close()

if __name__ == '__main__':
    main()
