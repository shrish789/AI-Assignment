import numpy as np
from queue import PriorityQueue

def convertStringToMatrix(state):
    puzzleMatrix = [[0 for i in range(3)] for j in range(3)]
    puzzleState = state
    for i in range(3):
        for j in range(3):
            puzzleMatrix[i][j] = int(puzzleState[i * 3 + j])
    return puzzleMatrix

def replaceTB(txt):
    txt = txt.replace("T", "")
    txt = txt.replace("B", "0")
    return txt

def show(puzzle):
    for i in range(0,3):
        for j in range(0,3):
            p = puzzle[i][j]
            if p != 0:
                print("T" + str(p), end =" ")
            else:
                print("B", end = " ")
        print("")
    print("")


# number of tiles displaced from their final position
def displacementHeuristics(puzzle, goalState):

    solved_puzzle = np.array(goalState)
    cost = puzzle != solved_puzzle
    cost = cost.astype(int)
    cost = np.sum(cost)
    idx = np.where(goalState == 0)
    x = int(idx[0])
    y = int(idx[1])

    if (puzzle[x][y] != 0):
        cost = cost - 1

    return cost

# manhattan distance from tile to final position
def manhattanHeuristics(puzzle, goalState):

    solved_puzzle = np.array(goalState)
    sum = 0
    for i in range(1,9):
        idx1 = np.where(solved_puzzle == i)
        idx2 = np.where(puzzle == i)

        dist = abs(idx1[0] - idx2[0]) + abs(idx1[1] - idx2[1])

        sum = sum + int(dist)

    return sum

# returns next successor states of puzzle
def successor_states(puzzle):

    idx = np.where(puzzle == 0)

    y = int(idx[0])
    x = int(idx[1])

    successor = []

    # blank can go up
    if (y != 0):
        temp = np.copy(puzzle)
        temp[y][x] = temp[y-1][x]
        temp[y-1][x] = 0
        successor.append(temp)

    # blank can go down
    if (y != 2):
        temp = np.copy(puzzle)
        temp[y][x] = temp[y+1][x]
        temp[y+1][x] = 0
        successor.append(temp)

    # blank can go to the left
    if (x != 0):
        temp = np.copy(puzzle)
        temp[y][x] = temp[y][x-1]
        temp[y][x-1] = 0
        successor.append(temp)

    # blank can go to the right
    if (x != 2):
        temp = np.copy(puzzle)
        temp[y][x] = temp[y][x+1]
        temp[y][x+1] = 0
        successor.append(temp)

    successor = np.array(successor)
    return successor


