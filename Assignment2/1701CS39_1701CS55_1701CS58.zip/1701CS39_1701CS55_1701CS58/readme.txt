To run 1. Genetic algorithm
            python3 geneticAlgorithm.py
       2. Simulated Annealing
            python3 simulatedAnnealing.py
