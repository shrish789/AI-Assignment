import random
from initial import *

MUTATION_CHANCE = 0.2
CROSS_OVER_RATE = 0.6
POPULATION = 10
MAX_ITERATION = 20
flag = 0




def generateState(person,startState):
    temp = np.copy(startState)

    global flag
    flag = 0
    prevState = np.copy(temp)

    for move in person:
        idx = np.where(temp == 0)
        # print(move)
        # show(temp)

        y = int(idx[0])
        x = int(idx[1])

        # blank can go up
        if (move == 'up' and y != 0):
            temp[y][x] = temp[y-1][x]
            temp[y-1][x] = 0


        # blank can go down
        if (move == 'down' and y != 2):
            temp[y][x] = temp[y+1][x]
            temp[y+1][x] = 0

        # blank can go to the left
        if (move == 'left' and x != 0):
            temp[y][x] = temp[y][x-1]
            temp[y][x-1] = 0

        # blank can go to the right
        if (move == 'right' and x != 2):
            temp[y][x] = temp[y][x+1]
            temp[y][x+1] = 0

        if np.array_equal(temp,prevState):
            flag = 1

            break
        prevState = np.copy(temp)


    return temp


def generate_gene(startState):

    st = np.copy(startState)
    temp = []
    length = random.randint(1,10)
    i=0
    gene = []
    moves = ['left','right','up','down']
    while True:
        while i<length:
            i = i+1
            gene.append(moves[random.randint(0,3)])
        generateState(gene,st)
        if flag == 0:
            return gene
        else:
            return temp



def find_fitness(population,heuristic,startState,goalState):

    st = np.copy(startState)
    gt = np.copy(goalState)
    fitness = []
    if heuristic == 1:
        heuristic_function = displacementHeuristics
    else:
        heuristic_function = manhattanHeuristics
    for person in population:
        currentState = generateState(person,st)
        # show(currentState)
        heuristic = heuristic_function(currentState,gt)
        # print(heuristic)
        if flag == 1:
            cur_fitness = 0
            fitness.append(cur_fitness)
        else:
            cur_fitness = 1.0/(0.001 + heuristic)
            fitness.append(cur_fitness)
        # print(person,cur_fitness)
        # print(fitness)

    return fitness

def select(fitness):
    sum = 0
    for cur in fitness:
        sum+=cur
    a=0
    b=0

    choice = random.random()*sum
    cur_sum = 0

    for i in range(len(fitness)):
        cur_sum+=fitness[i]
        if cur_sum >= choice:
            a = i
            break

    choice = random.random()*sum
    cur_sum = 0
    for i in range(len(fitness)):
        cur_sum+=fitness[i]
        if cur_sum >= choice:
            b = i
            break

    # print(fitness)
    # print(a,b)

    return a,b

def crossover(population,a,b,startState):
    st = np.copy(startState)


    prob = random.random()
    child1 =[]
    child2 =[]
    if(prob <= CROSS_OVER_RATE):
        crossover_point = random.randint(0,min(len(population[a]),len(population[b])))
        for i in range(crossover_point):
            child1.append(population[a][i])
            child2.append(population[b][i])

        i = crossover_point
        while i < max(len(population[a]),len(population[b])):
            if i < len(population[a]):
                child2.append(population[a][i])
            if i < len(population[b]):
                child1.append(population[b][i])
            i+=1

        generateState(child1,st)
        if flag == 0 and len(child1) < 30:
            chk = 0
            for p in population:
                if p == child1:
                    chk =1
            if chk == 0:
                population[a]=list.copy(child1)


        generateState(child2,st)
        if flag == 0 and len(child2) < 30:
            chk = 0
            for p in population:
                if p == child2:
                    chk =1
            if chk == 0:
                population[b]=list.copy(child2)


    return population


def mutate(population,a,b,startState):
    st = np.copy(startState)
    moves = ['left','right','up','down']
    for i in range(len(population[a])):
        prob = random.random()
        if prob <= MUTATION_CHANCE:
            population[a][i] = moves[random.randint(0,3)]

    for i in range(len(population[b])):
        prob = random.random()
        if prob <= MUTATION_CHANCE:
            population[b][i] = moves[random.randint(0,3)]
    neighbour = []
    meighbour = []


    for move in moves:
        neighbour = list.copy(population[a])
        neighbour.append(move)
        generateState(neighbour,st)
        if(len(neighbour) < 30 and flag == 0 ):
            chk = 0
            for p in population:
                if p == neighbour:
                    chk =1
            if chk == 0:
                population.append((neighbour))
                break

        meighbour = list.copy(population[b])
        meighbour.append(move)
        generateState(neighbour,st)
        if(len(neighbour) < 30 and flag == 0):
            chk = 0
            for p in population:
                if p == neighbour:
                    chk =1
            if chk == 0:
                population.append((neighbour))
                break




    return population




def genetic_algorithm(startState,goalState,choice):

    population = []
    i = 0
    max_fitness = 0
    optimal_gene = []
    while i<POPULATION:
        population.append(generate_gene(startState))
        i+=1

    generations = 0

    while generations < MAX_ITERATION:
        generations = generations +1
        fitness = find_fitness(population,choice,startState,goalState)


        for j in range(len(fitness)):

            if fitness[j] > max_fitness:
                generateState(population[j],startState)

                max_fitness = fitness[j]
                optimal_gene = list.copy(population[j])


            a,b = select(fitness)
            population = crossover(population,a,b,startState)
            population = mutate(population,a,b,startState)

    return optimal_gene









