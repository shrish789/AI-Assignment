import numpy as np
from queue import PriorityQueue

def convertStringToMatrix(state):
    puzzleMatrix = [[0 for i in range(3)] for j in range(3)]
    puzzleState = state
    for i in range(3):
        for j in range(3):
            puzzleMatrix[i][j] = int(puzzleState[i * 3 + j])
    return puzzleMatrix

def replaceTB(txt):
    txt = txt.replace("T", "")
    txt = txt.replace("B", "0")
    return txt

def show(board):
    for i in range(0,3):
        for j in range(0,3):
            p = board[i][j]
            if p != 0:
                print("T" + str(p), end =" ")
            else:
                print("B", end = " ")
        print("")
    print("")

def solvable(board):
    # returns whether a board is solvable

    invCount = True

    board = np.ravel(board)

    for i in range(9):
        for j in range(i+1,9):
            if board[i] > 0 and board[j] > 0 and board[i] > board[j]:
                invCount = not invCount

    return invCount

def h1(board,goalState):
    # number of tiles displaced from their final position

    solved_board = np.array(goalState)

    cost = board != solved_board

    cost = cost.astype(int)

    cost = np.sum(cost)

    if (board[2][2] != 0):
        cost = cost - 1

    return cost

def h2(board,goalState):
    # manhattan distance from tile to final position

    solved_board = np.array(goalState)

    sum = 0
    for i in range(1,9):
        idx1 = np.where(solved_board == i)
        idx2 = np.where(board == i)

        dist = abs(idx1[0] - idx2[0]) + abs(idx1[1] - idx2[1])

        sum = sum + int(dist)

    return sum

def possible_states(board):
    # returns next possible states of board

    # find location of 0
    idx = np.where(board == 0)

    y = int(idx[0])
    x = int(idx[1])

    possible = []

    if (y != 0):
        # 0 can go to the top
        copy = np.copy(board)
        copy[y][x] = copy[y-1][x]
        copy[y-1][x] = 0
        possible.append(copy)

    if (y != 2):
        # 0 can go to the bottom
        copy = np.copy(board)
        copy[y][x] = copy[y+1][x]
        copy[y+1][x] = 0
        possible.append(copy)

    if (x != 0):
        # 0 can go to the left
        copy = np.copy(board)
        copy[y][x] = copy[y][x-1]
        copy[y][x-1] = 0
        possible.append(copy)

    if (x != 2):
        # 0 can go to the right
        copy = np.copy(board)
        copy[y][x] = copy[y][x+1]
        copy[y][x+1] = 0
        possible.append(copy)

    possible = np.array(possible)

    return possible


