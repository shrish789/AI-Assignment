import time
from initial import *


def a_star_search(startState,board,goalState, h=1):

    vis = []
    size = 0
    par = []

    if h == 1:
        hf = h1
    else:
        hf = h2

    pq = PriorityQueue()
    cost = hf(board,goalState)
    g = 0

    tiebreaker = 0

    pq.put((cost, tiebreaker, board, board, 0, size))

    while cost-g > 0 and tiebreaker < 300:
        cost, _, board, parent, g, parid = pq.get()

        # print(board, cost-g)
        vis.append(board)
        size = size +1
        par.append(parid)

        possible = possible_states(board)

        for state in possible:
            for p in vis:
                if (state == p).all():
                    continue
            if np.array_equal(state, parent):
                continue

            state_cost = g + 1 + hf(state,goalState)
            pq.put((state_cost, tiebreaker, state, board, g + 1, size))

            tiebreaker = tiebreaker + 1

    if cost-g >0:
        print("Failure")
        print("Start State : ")
        show(startState)
        print("Goal State : ")
        show(goalState)
        print("Number of states explored = " + str(tiebreaker))
    else:
        print("Success")
        print("Start State : ")
        show(startState)
        print("Goal State : ")
        show(goalState)
        print("Number of states explored = " + str(tiebreaker))
        path = []
        path.append(vis[len(vis)-1])
        parid = par[len(vis) -1]
        while(parid > 0):
            path.append(vis[parid-1])
            parid = par[parid-1]

        for p in reversed(path):
            show(p)
        print("Optimal Path cost = " + str(len(path)-1))


if __name__ == '__main__':

    startState = ""
    goalState = ""
    with open("StartState") as f:
        for line in f:
            line = line.strip()
            line = line.replace(" ", "")
            startState += line
    startState = replaceTB(startState)
    startState = convertStringToMatrix(startState)
    startState = np.array(startState)

    with open("GoalState") as f:
        for line in f:
            line = line.strip()
            line = line.replace(" ", "")
            goalState += line

    goalState = replaceTB(goalState)
    goalState = convertStringToMatrix(goalState)
    goalState = np.array(goalState)

    # show menu
    print("Enter the Heuristic: ")
    print("1. h1(n) = number of tiles displaced from their destined position")
    print("2. h2(n) = sum of Manhattan distance of each tiles from the goal position.")


    # retrieve choice.
    choice = int(input("Enter your choice: "))
    if choice > 2 or choice <1:
        print("Invalid Choice.......\n")
    else:
        start = time.process_time()
        a_star_search(startState,startState,goalState,choice)
        print("Time taken by the program in seconds: ")
        print(time.process_time() - start)


