import time
from initial import *

def best_first_search(startState,board,goalState, h=1):

    vis = []
    size = 0
    par = []

    if h == 1:
        hf = h1
    else:
        hf = h2

    pq = PriorityQueue()
    cost = hf(board,goalState)

    tiebreaker = 0

    pq.put((cost, tiebreaker, board, board,size))

    while cost > 0 and tiebreaker < 1000:
        cost, _, board, parent, parid = pq.get()

        # print(board, cost)
        vis.append(board)
        size = size +1
        par.append(parid)

        possible = possible_states(board)

        for state in possible:
            for p in vis:
                if (state == p).all():
                    continue
            if np.array_equal(np.array(state), np.array(parent)):
                continue

            state_cost = hf(state,goalState)
            pq.put((state_cost, tiebreaker, state, board, size))

            tiebreaker = tiebreaker + 1

    if cost > 0:
        print("Failure")
        print("Start State : ")
        show(startState)
        print("Goal State : ")
        show(goalState)
        print("Number of states explored = " + str(tiebreaker))
    else:
        print("Success")
        print("Start State : ")
        show(startState)
        print("Goal State : ")
        show(goalState)
        print("Number of states explored = " + str(tiebreaker))
        path = []
        path.append(vis[len(vis)-1])
        parid = par[len(vis) -1]
        while(parid > 0):
            path.append(vis[parid-1])
            parid = par[parid-1]

        for p in reversed(path):
            show(p)
        print("Optimal Path cost = " + str(len(path)-1))


if __name__ == '__main__':

    startState = ""
    goalState = ""
    with open("StartState") as f:
        for line in f:
            line = line.strip()
            line = line.replace(" ", "")
            startState += line
    startState = replaceTB(startState)
    startState = convertStringToMatrix(startState)
    startState = np.array(startState)

    with open("GoalState") as f:
        for line in f:
            line = line.strip()
            line = line.replace(" ", "")
            goalState += line

    goalState = replaceTB(goalState)
    goalState = convertStringToMatrix(goalState)
    goalState = np.array(goalState)

    # show menu
    print("Enter the Heuristic: ")
    print("1. h1(n) = number of tiles displaced from their destined position")
    print("2. h2(n) = sum of Manhattan distance of each tiles from the goal position.")


    # retrieve choice.
    choice = int(input("Enter your choice: "))
    if choice > 2 or choice <1:
        print("Invalid Choice.......\n")
    else:
        start = time.process_time()
        best_first_search(startState,startState,goalState,choice)
        print("Time taken by the program in seconds: ")
        print(time.process_time() - start)


