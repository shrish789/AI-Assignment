import time
from initial import *


def hill_climbing_search(startState,board,goalState, h=1):

    vis = []
    size = 0
    par = []

    if h == 1:
        hf = h1
    else:
        hf = h2

    cost = hf(board,goalState)
    parent = board

    iterations = 0

    while cost > 0 and iterations < 1000:
        cost = hf(board,goalState)
        # print(board, cost)
        vis.append(board)
        size = size +1

        possible = possible_states(board)

        min_cost = 999
        min_board = None

        for state in possible:
            for p in vis:
                if (state == p).all():
                    continue

            if np.array_equal(state, parent):
                continue

            state_cost = hf(state, goalState)
            if (state_cost < min_cost):
                min_cost = state_cost
                min_board = np.copy(state)

        if min_cost == 999:
            break

        parent = np.copy(board)
        board = np.copy(min_board)

        iterations = iterations + 1

    if cost > 0:
        print("Failure")
        print("Start State : ")
        show(startState)
        print("Goal State : ")
        show(goalState)
        print("Number of states explored = " + str(iterations))
    else:
        print("Success")
        print("Start State : ")
        show(startState)
        print("Goal State : ")
        show(goalState)
        print("Number of states explored = " + str(iterations))
        # path = []
        # path.append(vis[len(vis)-1])
        # parid = par[len(vis) -1]
        # while(parid > 0):
        #     path.append(vis[parid-1])
        #     parid = par[parid-1]

        for p in vis:
            show(p)

        print("Optimal Path cost = " + str(len(vis)-1))


if __name__ == '__main__':

    startState = ""
    goalState = ""
    with open("StartState") as f:
        for line in f:
            line = line.strip()
            line = line.replace(" ", "")
            startState += line
    startState = replaceTB(startState)
    startState = convertStringToMatrix(startState)
    startState = np.array(startState)

    with open("GoalState") as f:
        for line in f:
            line = line.strip()
            line = line.replace(" ", "")
            goalState += line

    goalState = replaceTB(goalState)
    goalState = convertStringToMatrix(goalState)
    goalState = np.array(goalState)

    # show menu
    print("Enter the Heuristic: ")
    print("1. h1(n) = number of tiles displaced from their destined position")
    print("2. h2(n) = sum of Manhattan distance of each tiles from the goal position.")


    # retrieve choice.
    choice = int(input("Enter your choice: "))
    if choice > 2 or choice <1:
        print("Invalid Choice.......\n")
    else:
        start = time.process_time()
        hill_climbing_search(startState,startState,goalState,choice)
        print("Time taken by the program in seconds: ")
        print(time.process_time() - start)


