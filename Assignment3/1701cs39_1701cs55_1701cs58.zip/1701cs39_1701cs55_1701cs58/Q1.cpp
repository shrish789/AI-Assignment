#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
typedef long double ld;

#define alpha ios_base::sync_with_stdio(false);cin.tie(NULL);cout.tie(NULL);
#define pb push_back
#define mp make_pair
#define all(x) (x).begin(),(x).end()
#define ff first
#define ss second
#define fr(i,a,b) for(ll i=a; i<b; i++)
#define fr1(i,a,b) for(ll i=a; i>=b; i--)
#define input(arr,n) fr(i,0,n) cin>>arr[i]
#define output(arr,n) fr(i,0,n) cout<<arr[i]<<" "
#define min3(a, b, c) min(a,min(b, c))
#define min4(a, b, c, d) min(a, min(b, min(c, d)))
#define max3(a, b, c) max(a,max(b, c))
#define max4(a, b, c, d) max(a, max(b, max(c, d)))
#define vi vector<ll>
#define vii vector<pair<ll, ll> >
#define fixd(x) cout<<fixed<<setprecision(x);

#define dbg(args ...) cerr << __LINE__ << ": ", err(new istringstream(string(#args)), args), cerr << '\n'
void err(istringstream *iss) {}
template<typename T, typename ... Args> void err(istringstream *iss, const T &_val, const Args & ... args) {
    string _name;
    *iss >> _name;
    if (_name.back()==',') _name.pop_back();
    cerr << _name << " = " << _val << "; ", err(iss, args ...);
}

const ld PI = acosl(-1.0);


int prec_val(char c);

int main()
{
	cout<<"Please enter the Expression - \n";

	string initialString;
	getline(cin, initialString);

	set<char> findSet;

	for(int i=0; i<initialString.size(); i++)
	{
	  if(initialString[i]!='V' && initialString[i]>=(int)'A' && initialString[i]<=(int)'Z'){
		findSet.insert(initialString[i]);
	  }
	}

	string finalString = "";

	for(int i=0; i<initialString.size(); i++){
		if(initialString[i]==' ') continue;
		finalString += initialString[i];
	}

	initialString = finalString;
	finalString = "";

	for(int i=0; i<initialString.size(); i++){
		if(initialString[i] == '='){
			if(finalString[finalString.size()-1] == ')'){
				int j = finalString.size()-2;
				while(j>=0 && initialString[j] != '(') j--;

				finalString.insert(j, "~");
			}
			else{
				int j = finalString.size()-1;
				finalString.insert(j, "~");
			}
			finalString += "V";
			i++;
		}
		else{
			finalString += initialString[i];
		}
	}

	initialString = finalString;
	finalString = "";

	stack<char> operatorStack;

	for(int i=0; i<initialString.size(); i++){
		if(initialString[i]>='A' && initialString[i]<='Z' && initialString[i]!='V'){
			  finalString+=initialString[i];
		}
		else if(initialString[i]=='^' || initialString[i]=='V' || initialString[i]=='~'){
			while(!operatorStack.empty() && operatorStack.top()!='(' && prec_val(operatorStack.top()) > prec_val(initialString[i])){
				finalString += operatorStack.top();
				operatorStack.pop();
			}
			operatorStack.push(initialString[i]); 
		}
		else if(initialString[i]=='('){
			operatorStack.push(initialString[i]);
		}
		else if(initialString[i]==')'){
			while(!operatorStack.empty() && operatorStack.top()!='('){
				finalString+=operatorStack.top();
				operatorStack.pop();
			}
			operatorStack.pop();
		}
	}

	while(!operatorStack.empty()){
		finalString += operatorStack.top();
		operatorStack.pop();
	}

	initialString = finalString;

	int numberPower = findSet.size();
	bool flag = true;

	for(int j=0; j<pow(2,numberPower); j++) 
	{
		bitset<20> b(j);

		unordered_map<char,int> value;

		int i=0;
		for(auto x : findSet){
			value[x]=b[i];
			i++;
		}

		stack<int> valueStack;

		for(int i=0; i<initialString.size(); i++){
			if(initialString[i]>='A' && initialString[i]<='Z' && initialString[i]!='V'){
				valueStack.push(value[initialString[i]]);
			}
			else if(initialString[i]=='~'){
				int operand=valueStack.top();
				valueStack.pop();
				operand = 1-operand;
				valueStack.push(operand);
			}
			else if(initialString[i]=='V'){
				int operand1=valueStack.top();
				valueStack.pop();
				int operand2=valueStack.top();
				valueStack.pop();
				valueStack.push(operand1 | operand2);
			}
			else if(initialString[i]=='^'){
				int operand1=valueStack.top();
				valueStack.pop();
				int operand2=valueStack.top();
				valueStack.pop();
				valueStack.push(operand1 & operand2);
			}
		}

		if(valueStack.top() == 0) flag=false;
	}

	if(flag) cout<<"Yes, That is a Theorem!\n";
	else cout<<"No, That is not a Theorem!\n";

	return 0;
}

int prec_val(char c){
	if(c=='~') return 3;
	if(c=='^') return 2;
	if(c=='V') return 1;
	return 0;
}