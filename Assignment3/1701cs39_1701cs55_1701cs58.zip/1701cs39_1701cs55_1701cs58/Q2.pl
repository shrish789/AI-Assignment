himalayan_club_member(a).
himalayan_club_member(b).
himalayan_club_member(c).


likes(a,rain).
likes(a,snow).

dislikes(b,X):-likes(a,X).
likes(a,X):-likes(b,X),!,fail.
likes(a,X).

not_himalayan_club_member(X):-not_a_mountain_climber(X),not_a_skier(X).

a_mountain_climber(X):-likes(X,rain),!,fail.
a_mountain_climber(X).

not_a_skier(X):-dislikes(X,snow).

not_a_mountain_climber(X):-a_mountain_climber(X),!,fail.
not_a_mountain_climber(X).


dislikes(X,Y):-likes(X,Y),!,fail.
dislikes(X,Y).


a_skier(X):-not_a_skier(X),!,fail.
a_skier(X).

himalayan_club_member(X):-not_himalayan_club_member(X),!,fail.
himalayan_club_member(X).

question(X):-himalayan_club_member(X),a_mountain_climber(X),not_a_skier(X),!.