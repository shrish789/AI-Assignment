from sklearn.tree import DecisionTreeClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.naive_bayes import GaussianNB
import numpy as np
import pandas as pd
from sklearn.metrics import accuracy_score
import warnings

warnings.simplefilter("ignore")

def resultOfDecisionTree(X_train, y_train, X_test, y_test, clf):
	clf.fit(X_train, y_train)
	y_pred = clf.predict(X_test)
	acc = accuracy_score(y_test, y_pred)

	return acc

def splitData(datasetDataframe, train_split=0.6, test_split=0.2, val_split=0.2):
	trainingDataset, validationDataset, testingDataset = np.split(datasetDataframe.sample(frac=1, random_state=42), [int(train_split*len(datasetDataframe)), int((train_split+val_split)*len(datasetDataframe))])
	return trainingDataset, validationDataset, testingDataset


def votingForWeightage(X_train, y_train, X_val, y_val, X_test, y_test, classifierList):
	predictions = []
	weights = []

	for clf in classifierList:
		clf.fit(X_train, y_train)
		y_pred_val = clf.predict(X_val)

		weight = accuracy_score(y_test, y_pred_val)
		weights.append(weight)

	X_train_das = pd.concat([X_train, X_val])
	y_train_das = pd.concat([y_train, y_val])

	for clf in classifierList:
		clf.fit(X_train_das, y_train_das)
		y_pred = clf.predict(X_test)
		predictions.append(y_pred)

	y_pred = []

	for i in range(len(predictions[0])):
		pred = (weights[0]*predictions[0][i]) + (weights[1]*predictions[1][i]) + (weights[2]*predictions[2][i])

		pred = pred / sum(weights)

		if pred >= 0.5:
			y_pred.append(1)
		else:
			y_pred.append(0)

	return np.array(y_pred)

def votingForMajority(X_train, y_train, X_test, y_val, classifierList):
	predictions = []

	for clf in classifierList:
		clf.fit(X_train, y_train)
		y_pred = clf.predict(X_test)
		predictions.append(y_pred)

	y_pred = []

	for i in range(len(predictions[0])):
		pred = predictions[0][i] + predictions[1][i] + predictions[2][i]

		if pred >= 2:
			y_pred.append(1)
		else:
			y_pred.append(0)

	return np.array(y_pred)

