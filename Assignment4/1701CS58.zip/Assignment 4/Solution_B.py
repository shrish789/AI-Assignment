from sklearn.tree import DecisionTreeClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.naive_bayes import GaussianNB
from sklearn.tree import DecisionTreeClassifier
import numpy as np
import pandas as pd
from sklearn.metrics import accuracy_score
from Utility import *

datasetDataframe = pd.read_csv("ReplicatedAcousticFeatures-ParkinsonDatabase.csv")

datasetDataframe = datasetDataframe.loc[:, datasetDataframe.columns != 'ID']

# Split the Data into Training, Testing & Validation Dataset
trainingDataset, validationDataset, testingDataset = splitData(datasetDataframe)

# Get the Features and Labels
X_train, y_train = trainingDataset.loc[:, trainingDataset.columns != 'Status'], trainingDataset.loc[:, trainingDataset.columns == 'Status']
X_val, y_val = validationDataset.loc[:, validationDataset.columns != 'Status'], validationDataset.loc[:, validationDataset.columns == 'Status']
X_test, y_test = testingDataset.loc[:, testingDataset.columns != 'Status'], testingDataset.loc[:, testingDataset.columns == 'Status']

X_train_das = pd.concat([X_train, X_val])
y_train_das = pd.concat([y_train, y_val])



##############################################################################################


# Version 1
print("Version 1 Parameters")
print("-"*50)
print("Logistic Regression: Penalty = L1 & Primal Formulation = False & Solver = liblinear")
print("Naive Bayes: Prior on Classes = (label1:0.5), (label2:0.5)")
print("Decision Tree: Max Depth=5\n")

classifier1 = LogisticRegression(penalty='l1', solver='liblinear')
classifier2 = GaussianNB([[0.5],[0.5]])
classifier3 = DecisionTreeClassifier(max_depth=5)

classifierList = [classifier1, classifier2, classifier3]

# Majority Voting
y_pred = votingForMajority(X_train_das, y_train_das, X_test, y_test, classifierList)
majorityAccuracy = accuracy_score(y_test, y_pred)


# Weighted Voting
y_pred = votingForWeightage(X_train, y_train, X_val, y_val, X_test, y_test, classifierList)
weightedAccuracy = accuracy_score(y_test, y_pred)

# Individual Classifiers

# Logistic Regression
logisticRegressionAccuracy = resultOfDecisionTree(X_train_das, y_train_das, X_test, y_test, classifier1)

# Naive Bayes
naiveBayesAccuracy = resultOfDecisionTree(X_train_das, y_train_das, X_test, y_test, classifier2)

# Decision Trees
decisionTreeAccuracy = resultOfDecisionTree(X_train_das, y_train_das, X_test, y_test, classifier3)

# Print Results
print("Accuracy of Individual Classifiers:")
print("Accuracy of Logistic Regression: {}".format(logisticRegressionAccuracy))
print("Accuracy of Naive Bayes: {}".format(naiveBayesAccuracy))
print("Accuracy of Decision Trees: {}".format(decisionTreeAccuracy))

print("\n")

print("Accuracy of Ensembling Methods:")
print("Accuracy of Majority Voting: {}".format(majorityAccuracy))
print("Accuracy of Weighted Voting: {}".format(weightedAccuracy))

##############################################################################################

# Version 2
print("\n\nVersion 2 Parameters")
print("-"*50)
print("Logistic Regression: Penalty = L2 & Primal Formulation = False & Solver = lbfgs")
print("Naive Bayes: Prior on Classes = (label1:0.4), (label2:0.6)")
print("Decision Tree: Max Depth=10\n")

classifier1 = LogisticRegression(penalty='l2')
classifier2 = GaussianNB([[0.4],[0.6]])
classifier3 = DecisionTreeClassifier(max_depth=10)

classifierList = [classifier1, classifier2, classifier3]

# Majority Voting
y_pred = votingForMajority(X_train_das, y_train_das, X_test, y_test, classifierList)
majorityAccuracy = accuracy_score(y_test, y_pred)


# Weighted Voting
y_pred = votingForWeightage(X_train, y_train, X_val, y_val, X_test, y_test, classifierList)
weightedAccuracy = accuracy_score(y_test, y_pred)

# Individual Classifiers

# Logistic Regression
logisticRegressionAccuracy = resultOfDecisionTree(X_train_das, y_train_das, X_test, y_test, classifier1)

# Naive Bayes
naiveBayesAccuracy = resultOfDecisionTree(X_train_das, y_train_das, X_test, y_test, classifier2)

# Decision Trees
decisionTreeAccuracy = resultOfDecisionTree(X_train_das, y_train_das, X_test, y_test, classifier3)

# Print Results
print("Accuracy of Individual Classifiers:")
print("Accuracy of Logistic Regression: {}".format(logisticRegressionAccuracy))
print("Accuracy of Naive Bayes: {}".format(naiveBayesAccuracy))
print("Accuracy of Decision Trees: {}".format(decisionTreeAccuracy))

print("\n")

print("Accuracy of Ensembling Methods:")
print("Accuracy of Majority Voting: {}".format(majorityAccuracy))
print("Accuracy of Weighted Voting: {}".format(weightedAccuracy))

##############################################################################################

# Version 3
print("\n\nVersion 3 Parameters")
print("-"*50)
print("Logistic Regression: Penalty = Elasticnet & Primal Formulation = False & Solver = SaGa")
print("Naive Bayes: Prior on Classes = (label1:0.6), (label2:0.4)")
print("Decision Tree: Max Depth=15\n")

classifier1 = LogisticRegression(penalty='l2', solver='saga')
classifier2 = GaussianNB([[0.6],[0.4]])
classifier3 = DecisionTreeClassifier(max_depth=15)

classifierList = [classifier1, classifier2, classifier3]

# Majority Voting
y_pred = votingForMajority(X_train_das, y_train_das, X_test, y_test, classifierList)
majorityAccuracy = accuracy_score(y_test, y_pred)


# Weighted Voting
y_pred = votingForWeightage(X_train, y_train, X_val, y_val, X_test, y_test, classifierList)
weightedAccuracy = accuracy_score(y_test, y_pred)

# Individual Classifiers

# Logistic Regression
logisticRegressionAccuracy = resultOfDecisionTree(X_train_das, y_train_das, X_test, y_test, classifier1)

# Naive Bayes
naiveBayesAccuracy = resultOfDecisionTree(X_train_das, y_train_das, X_test, y_test, classifier2)

# Decision Trees
decisionTreeAccuracy = resultOfDecisionTree(X_train_das, y_train_das, X_test, y_test, classifier3)

# Print Results
print("Accuracy of Individual Classifiers:")
print("Accuracy of Logistic Regression: {}".format(logisticRegressionAccuracy))
print("Accuracy of Naive Bayes: {}".format(naiveBayesAccuracy))
print("Accuracy of Decision Trees: {}".format(decisionTreeAccuracy))

print("\n")

print("Accuracy of Ensembling Methods:")
print("Accuracy of Majority Voting: {}".format(majorityAccuracy))
print("Accuracy of Weighted Voting: {}".format(weightedAccuracy))

##############################################################################################

# Version 4
print("\n\nVersion 4 Parameters")
print("-"*50)
print("Logistic Regression: Penalty = None & Primal Formulation = False & Solver = lbfgs")
print("Naive Bayes: Prior on Classes = (label1:0.3), (label2:0.7)")
print("Decision Tree: Max Depth=25\n")

classifier1 = LogisticRegression(penalty='none')
classifier2 = GaussianNB([[0.3],[0.7]])
classifier3 = DecisionTreeClassifier(max_depth=25)

classifierList = [classifier1, classifier2, classifier3]

# Majority Voting
y_pred = votingForMajority(X_train_das, y_train_das, X_test, y_test, classifierList)
majorityAccuracy = accuracy_score(y_test, y_pred)


# Weighted Voting
y_pred = votingForWeightage(X_train, y_train, X_val, y_val, X_test, y_test, classifierList)
weightedAccuracy = accuracy_score(y_test, y_pred)

# Individual Classifiers

# Logistic Regression
logisticRegressionAccuracy = resultOfDecisionTree(X_train_das, y_train_das, X_test, y_test, classifier1)

# Naive Bayes
naiveBayesAccuracy = resultOfDecisionTree(X_train_das, y_train_das, X_test, y_test, classifier2)

# Decision Trees
decisionTreeAccuracy = resultOfDecisionTree(X_train_das, y_train_das, X_test, y_test, classifier3)

# Print Results
print("Accuracy of Individual Classifiers:")
print("Accuracy of Logistic Regression: {}".format(logisticRegressionAccuracy))
print("Accuracy of Naive Bayes: {}".format(naiveBayesAccuracy))
print("Accuracy of Decision Trees: {}".format(decisionTreeAccuracy))

print("\n")

print("Accuracy of Ensembling Methods:")
print("Accuracy of Majority Voting: {}".format(majorityAccuracy))
print("Accuracy of Weighted Voting: {}".format(weightedAccuracy))

##############################################################################################

# Version 5
print("\n\nVersion 5 Parameters")
print("-"*50)
print("Logistic Regression: Penalty = L2 & Primal Formulation = True & Solver = liblinear")
print("Naive Bayes: Prior on Classes = (label1:0.7), (label2:0.3)")
print("Decision Tree: Max Depth=35\n")

classifier1 = LogisticRegression(penalty='l2', dual=True, solver='liblinear')
classifier2 = GaussianNB([[0.7],[0.3]])
classifier3 = DecisionTreeClassifier(max_depth=35)

classifierList = [classifier1, classifier2, classifier3]

# Majority Voting
y_pred = votingForMajority(X_train_das, y_train_das, X_test, y_test, classifierList)
majorityAccuracy = accuracy_score(y_test, y_pred)


# Weighted Voting
y_pred = votingForWeightage(X_train, y_train, X_val, y_val, X_test, y_test, classifierList)
weightedAccuracy = accuracy_score(y_test, y_pred)

# Individual Classifiers

# Logistic Regression
logisticRegressionAccuracy = resultOfDecisionTree(X_train_das, y_train_das, X_test, y_test, classifier1)

# Naive Bayes
naiveBayesAccuracy = resultOfDecisionTree(X_train_das, y_train_das, X_test, y_test, classifier2)

# Decision Trees
decisionTreeAccuracy = resultOfDecisionTree(X_train_das, y_train_das, X_test, y_test, classifier3)

# Print Results
print("Accuracy of Individual Classifiers:")
print("Accuracy of Logistic Regression: {}".format(logisticRegressionAccuracy))
print("Accuracy of Naive Bayes: {}".format(naiveBayesAccuracy))
print("Accuracy of Decision Trees: {}".format(decisionTreeAccuracy))

print("\n")

print("Accuracy of Ensembling Methods:")
print("Accuracy of Majority Voting: {}".format(majorityAccuracy))
print("Accuracy of Weighted Voting: {}".format(weightedAccuracy))

##############################################################################################