from sklearn.tree import DecisionTreeClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.naive_bayes import GaussianNB
from sklearn.tree import DecisionTreeClassifier
import numpy as np
import pandas as pd
from sklearn.metrics import accuracy_score
from Utility import *

datasetDataframe = pd.read_csv("ReplicatedAcousticFeatures-ParkinsonDatabase.csv")

datasetDataframe = datasetDataframe.loc[:, datasetDataframe.columns != 'ID']

# Split the Data into Training, Testing & Validation Dataset
trainingDataset, validationDataset, testingDataset = splitData(datasetDataframe)

# Get the Features and Labels
X_train, y_train = trainingDataset.loc[:, trainingDataset.columns != 'Status'], trainingDataset.loc[:, trainingDataset.columns == 'Status']
X_val, y_val = validationDataset.loc[:, validationDataset.columns != 'Status'], validationDataset.loc[:, validationDataset.columns == 'Status']
X_test, y_test = testingDataset.loc[:, testingDataset.columns != 'Status'], testingDataset.loc[:, testingDataset.columns == 'Status']

# Classifiers
classifier1 = LogisticRegression()
classifier2 = GaussianNB()
classifier3 = DecisionTreeClassifier()

classifierList = [classifier1, classifier2, classifier3]

# Majority Voting
X_train_das = pd.concat([X_train, X_val])
y_train_das = pd.concat([y_train, y_val])

y_pred = votingForMajority(X_train_das, y_train_das, X_test, y_test, classifierList)
majorityAccuracy = accuracy_score(y_test, y_pred)


# Weighted Voting
y_pred = votingForWeightage(X_train, y_train, X_val, y_val, X_test, y_test, classifierList)
weightedAccuracy = accuracy_score(y_test, y_pred)

# Individual Classifiers

# Logistic Regression
logisticRegressionAccuracy = resultOfDecisionTree(X_train_das, y_train_das, X_test, y_test, classifier1)

# Naive Bayes
naiveBayesAccuracy = resultOfDecisionTree(X_train_das, y_train_das, X_test, y_test, classifier2)

# Decision Trees
decisionTreeAccuracy = resultOfDecisionTree(X_train_das, y_train_das, X_test, y_test, classifier3)

# Print Results
print("Accuracy of Individual Classifiers:")
print("Accuracy of Decision Trees: {}".format(decisionTreeAccuracy))
print("Accuracy of Logistic Regression: {}".format(logisticRegressionAccuracy))
print("Accuracy of Naive Bayes: {}".format(naiveBayesAccuracy))

print("\n")

print("Accuracy of Ensembling Methods:")
print("Accuracy of Majority Voting: {}".format(majorityAccuracy))
print("Accuracy of Weighted Voting: {}".format(weightedAccuracy))